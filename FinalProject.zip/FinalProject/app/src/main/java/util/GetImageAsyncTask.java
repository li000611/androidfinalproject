package util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetImageAsyncTask extends AsyncTask<Object, Integer, Bitmap> {
    ImageView imgView;
    String url ;
    String fileName;
    Context ctx;
    ProgressBar progressBar;
    View container;

    public GetImageAsyncTask(String url, ImageView imgView, String fileName, Context ctx, ProgressBar progressBar, View container) {
        super();
        this.imgView = imgView;
        this.url = url;
        this.fileName = fileName;
        this.ctx = ctx;
        this.progressBar = progressBar;
        this.container = container;
    }


    @Override
    protected Bitmap doInBackground(Object... objects) {
        if(url == null || url.isEmpty()) return null;
        try {
            publishProgress(50);
            URL url = new URL(this.url);
            HttpURLConnection connection = (HttpURLConnection) url
                    .openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);

            if(fileName != null && !fileName.isEmpty()) {
                FileOutputStream outputStream = ctx.openFileOutput(fileName, Context.MODE_PRIVATE);
                myBitmap.compress(Bitmap.CompressFormat.PNG, 80, outputStream);
                outputStream.flush();
                outputStream.close();
            }
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

//    imgView.setImageBitmap(myBitmap);
    @Override
    protected void onPostExecute(Bitmap s) {
        if(s == null) return;
        imgView.setImageBitmap(s);
        if(progressBar != null) {
            progressBar.setVisibility(View.INVISIBLE);
        }
        if(container != null) {
            container.setAlpha(1);
            container.setClickable(Boolean.TRUE);
        }
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        if(progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        if(container != null) {
            container.setAlpha(0.2f);
            container.setClickable(Boolean.FALSE);
        }
    }
}

