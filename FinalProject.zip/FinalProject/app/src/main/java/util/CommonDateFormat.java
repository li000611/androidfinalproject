package util;

import java.text.SimpleDateFormat;

public class CommonDateFormat {
    public static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");
    public static final SimpleDateFormat BBC_NEWS_DATE_FORMAT = new SimpleDateFormat("EEE, dd MMM yyyy kk:mm:ss zzz");
    public static final SimpleDateFormat NASA_IMAGE_OF_THE_DAY_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
}
