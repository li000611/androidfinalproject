package com.example.finalproject.ui.NasaImageOfTheDay;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.finalproject.R;
import com.example.finalproject.adapter.NasaImageOfTheDay.ImageAdapter;
import com.example.finalproject.async.NasaImageOfTheDay.NasaImageGet;
import com.example.finalproject.model.NasaImageOfTheDay.NasaImage;
import com.example.finalproject.opener.DatabaseOpener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class NasaImageOfTheDayFragment extends Fragment {
    public static String NASA_IMAGE_INTENT_EXTRA = "nasa_image";
    public static String ALLOW_FAVORITE_INTENT_EXTRA = "allow_favorite";

    private FloatingActionButton searchBtn;
    private View root;
    private DatabaseOpener dbOpener;
    private List<NasaImage> images;
    private ImageAdapter adapter;
    private ListView listView;
    private ProgressBar loadingBar;
    private View container;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dbOpener = new DatabaseOpener(getContext());
        root = inflater.inflate(R.layout.list_template
                , container, false);

        loadingBar = root.findViewById(R.id.loading_bar);
        loadingBar.setVisibility(View.INVISIBLE);

        this.container = root.findViewById(R.id.list_container);
        images = NasaImage.getAll(dbOpener);

        adapter = new ImageAdapter(images, getContext(), loadingBar, this.container);

        listView = root.findViewById(R.id.template_list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            NasaImage selectedImg = this.images.get(position);
            Intent intent = new Intent(getContext(), NasaImageOfTheDayDetailActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable(NASA_IMAGE_INTENT_EXTRA, selectedImg);
            bundle.putBoolean(ALLOW_FAVORITE_INTENT_EXTRA, Boolean.FALSE);
            intent.putExtras(bundle);
            startActivity(intent);
        });

        listView.setOnItemLongClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(getString(R.string.delete_this_nasa_image));
            builder.setPositiveButton(getText(R.string.OK), (dialog, which) -> {
                NasaImage selectedImg = this.images.get(position);
                NasaImage.delete(this.dbOpener, selectedImg.getId());
                this.images.remove(position);
                this.adapter.notifyDataSetChanged();
                Snackbar.make(getActivity().findViewById(R.id.drawer_layout), R.string.deleted_success, Snackbar.LENGTH_SHORT).show();
            }).setNegativeButton(getText(R.string.cancel), null);
            AlertDialog dialog = builder.create();
            dialog.show();
            return true;
        });

        searchBtn = root.findViewById(R.id.search_btn);
        searchBtn.setOnClickListener(e -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(getString(R.string.nasa_image_of_the_day_pls_enter_your_date));

            Calendar cal = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    getContext(), (DatePicker view, int year, int month, int dayOfMonth) -> {
                Calendar formatCal = Calendar.getInstance();
                formatCal.set(year, month, dayOfMonth);
                new NasaImageGet(getContext(), this.loadingBar, formatCal.getTime(), this.container).execute();
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.getDatePicker().setMaxDate(new Date().getTime());
            datePickerDialog.show();
        });

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        this.images = NasaImage.getAll(dbOpener);
        this.adapter.setImages(this.images);
        this.adapter.notifyDataSetChanged();
    }
}
