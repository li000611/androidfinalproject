package com.example.finalproject.model.NasaImageOfTheDay;

import android.content.ContentValues;
import android.database.Cursor;

import com.example.finalproject.opener.DatabaseOpener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NasaImage implements Serializable {
    private Long id;
    private String url;
    private Date date;
    private String hdUrl;

    public NasaImage(Long id, String url, Date date, String hdUrl) {
        this.id = id;
        this.url = url;
        this.date = date;
        this.hdUrl = hdUrl;
    }

    public static List<NasaImage> getAll(DatabaseOpener dbOpener) {
        List<NasaImage> res = new ArrayList<>();

        Cursor cursor = dbOpener.getReadableDatabase().query(DatabaseOpener.NASA_IMAGE_TABLE_NAME, null, null, null, null, null, DatabaseOpener.NASA_IMAGE_TABLE_DATE_COL + " DESC");
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                Long id = cursor.getLong(cursor.getColumnIndex(DatabaseOpener.NASA_IMAGE_TABLE_ID_COL));
                String url = cursor.getString(cursor.getColumnIndex(DatabaseOpener.NASA_IMAGE_TABLE_URL_COL));
                String hdUrl = cursor.getString(cursor.getColumnIndex(DatabaseOpener.NASA_IMAGE_TABLE_HDURL_COL));
                Date date = new Date((long) cursor.getInt(cursor.getColumnIndex(DatabaseOpener.NASA_IMAGE_TABLE_DATE_COL)) * 1000);

                res.add(new NasaImage(id, url, date, hdUrl));

                cursor.moveToNext();
            }
        }

        return res;
    }

    public static Long insert(DatabaseOpener dbOpener, NasaImage image) {
        ContentValues newImg = new ContentValues();
        newImg.put(DatabaseOpener.NASA_IMAGE_TABLE_URL_COL, image.getUrl());
        newImg.put(DatabaseOpener.NASA_IMAGE_TABLE_DATE_COL, (int) (image.getDate().getTime() / 1000));
        newImg.put(DatabaseOpener.NASA_IMAGE_TABLE_HDURL_COL, image.getHdUrl());
        return dbOpener.getWritableDatabase().insert(DatabaseOpener.NASA_IMAGE_TABLE_NAME, null, newImg);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getHdUrl() {
        return hdUrl;
    }

    public void setHdUrl(String hdUrl) {
        this.hdUrl = hdUrl;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public static int delete(DatabaseOpener dbOpener, Long id) {
        return dbOpener.getWritableDatabase().delete(DatabaseOpener.NASA_IMAGE_TABLE_NAME, String.format("%s = ?", DatabaseOpener.NASA_IMAGE_TABLE_ID_COL), new String[]{Long.toString(id)});
    }
}
