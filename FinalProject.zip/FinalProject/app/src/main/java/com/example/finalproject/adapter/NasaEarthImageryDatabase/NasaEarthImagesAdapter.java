package com.example.finalproject.adapter.NasaEarthImageryDatabase;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.finalproject.R;
import com.example.finalproject.model.NasaEarthImage.NasaEarthImage;

import java.io.FileNotFoundException;
import java.util.List;

import util.GetImageAsyncTask;

public class NasaEarthImagesAdapter extends BaseAdapter {
    private Context context;
    private List<NasaEarthImage> images;
    private ProgressBar progressBar;
    private View container;

    public NasaEarthImagesAdapter(List<NasaEarthImage> list, Context context, ProgressBar progressBar, View container) {
        setImages(list);
        setContext(context);
        this.progressBar = progressBar;
        this.container = container;
    }

    public void setContext(Context context) {
        this.context = context;
    }


    public void setImages(List<NasaEarthImage> images) {
        this.images = images;
    }

    @Override
    public int getCount() {
        return images.size();
    }

    @Override
    public NasaEarthImage getItem(int position) {
        return images.get(position);
    }

    @Override
    public long getItemId(int position) {
        return images.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.nasa_earth_image_list_item, parent, false);
        }

        ImageView imgView = convertView.findViewById(R.id.list_item_earth_image);
        TextView longlatView = convertView.findViewById(R.id.list_item_long_lat);
        NasaEarthImage img = images.get(position);
        String fileName = img.getId() + ".nasaearthimage.png";
        try {
            if(img.getId() == null) throw new FileNotFoundException();
            imgView.setImageBitmap(BitmapFactory.decodeStream(context.openFileInput(fileName)));
        } catch (FileNotFoundException e) {
            new GetImageAsyncTask(img.getUrl(), imgView, fileName, context, progressBar, container).execute();
        }

        longlatView.setText(String.format("%.4f, %.4f", img.getLatitude(), img.getLongitude()));
        return convertView;
    }
}
