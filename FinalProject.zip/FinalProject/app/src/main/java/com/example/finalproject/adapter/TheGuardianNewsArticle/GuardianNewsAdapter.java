package com.example.finalproject.adapter.TheGuardianNewsArticle;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.finalproject.R;
import com.example.finalproject.model.TheGuardianNewsArticle.GuardianArticle;

import java.util.List;

public class GuardianNewsAdapter extends BaseAdapter {
    private Context context;
    private List<GuardianArticle> articles;

    public GuardianNewsAdapter(List<GuardianArticle> list, Context context) {
        setArticles(list);
        setContext(context);
    }

    public void setContext(Context context) {
        this.context = context;
    }


    public void setArticles(List<GuardianArticle> articles) {
        this.articles = articles;
    }

    @Override
    public int getCount() {
        return articles.size();
    }

    @Override
    public GuardianArticle getItem(int position) {
        return articles.get(position);
    }

    @Override
    public long getItemId(int position) {
        Long id = articles.get(position).getId();
        return id == null ? 0 : id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.guardian_article_list_item, parent, false);
        }

        TextView titleView = convertView.findViewById(R.id.guardian_article_list_item_title);
        TextView sectionView = convertView.findViewById(R.id.guardian_article_list_item_section);

        titleView.setText(articles.get(position).getTitle());
        sectionView.setText(articles.get(position).getSection());

        return convertView;
    }
}
