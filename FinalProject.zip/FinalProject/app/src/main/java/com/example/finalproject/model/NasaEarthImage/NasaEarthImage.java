package com.example.finalproject.model.NasaEarthImage;

import android.content.ContentValues;
import android.database.Cursor;

import com.example.finalproject.opener.DatabaseOpener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NasaEarthImage implements Serializable {
    private Long id;
    private double longitude;
    private double latitude;
    private Date date;
    private String url;

    public NasaEarthImage(Long id, double longitude, double latitude, Date date, String url) {
        this.id = id;
        this.longitude = longitude;
        this.latitude = latitude;
        this.date = date;
        this.url = url;
    }

    public static List<NasaEarthImage> getAll(DatabaseOpener dbOpener) {
        List<NasaEarthImage> res = new ArrayList<>();

        Cursor cursor = dbOpener.getReadableDatabase().query(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_NAME, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                Long id = cursor.getLong(cursor.getColumnIndex(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_ID_COL));
                float latitude = cursor.getFloat(cursor.getColumnIndex(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_LATITUDE_COL));
                float longitude = cursor.getFloat(cursor.getColumnIndex(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_LONGITUDE_COL));
                Date date = new Date((long) cursor.getInt(cursor.getColumnIndex(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_DATE_COL)) * 1000);
                String url = cursor.getString(cursor.getColumnIndex(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_URL_COL));
                res.add(new NasaEarthImage(id, longitude, latitude, date, url));
                cursor.moveToNext();
            }
        }

        return res;
    }

    public static int delete(DatabaseOpener dbOpener, Long id) {
        return dbOpener.getWritableDatabase().delete(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_NAME, String.format("%s = ?", DatabaseOpener.NASA_EARTH_IMAGE_TABLE_ID_COL), new String[]{Long.toString(id)});
    }

    public static Long insert(DatabaseOpener dbOpener, NasaEarthImage image) {
        ContentValues newImg = new ContentValues();
        newImg.put(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_LATITUDE_COL, image.getLatitude());
        newImg.put(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_LONGITUDE_COL, image.getLongitude());
        newImg.put(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_DATE_COL, (int) (image.getDate().getTime() / 1000));
        newImg.put(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_URL_COL, image.getUrl());
        return dbOpener.getWritableDatabase().insert(DatabaseOpener.NASA_EARTH_IMAGE_TABLE_NAME, null, newImg);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
