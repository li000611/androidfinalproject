package com.example.finalproject.ui.NasaEarthImageryDatabase;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.finalproject.R;
import com.example.finalproject.adapter.NasaEarthImageryDatabase.NasaEarthImagesAdapter;
import com.example.finalproject.async.NasaEarthImageryDatabase.EarthImageGet;
import com.example.finalproject.model.NasaEarthImage.NasaEarthImage;
import com.example.finalproject.opener.DatabaseOpener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class NasaEarthImageryDatabaseFragment extends Fragment {
    public static String IMAGES_INTENT_EXTRA = "images";
    public static String IMAGE_INTENT_EXTRA = "image";
    public static String FROM_LIST_PAGE_INTENT_EXTRA = "from_list_page";

    private FloatingActionButton searchBtn;
    private View root;
    private DatabaseOpener dbOpener;
    private List<NasaEarthImage> images;
    private NasaEarthImagesAdapter adapter;
    private ListView listView;
    private ProgressBar loadingBar;
    private View container;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dbOpener = new DatabaseOpener(getContext());
        root = inflater.inflate(R.layout.list_template
                , container, false);

        loadingBar = root.findViewById(R.id.loading_bar);
        loadingBar.setVisibility(View.INVISIBLE);

        this.container = root.findViewById(R.id.list_container);
        images = NasaEarthImage.getAll(dbOpener);

        adapter = new NasaEarthImagesAdapter(images, getContext(), loadingBar, this.container);

        listView = root.findViewById(R.id.template_list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            Intent intent = new Intent(getContext(), NasaEarthImageryDetail.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable(NasaEarthImageryDatabaseFragment.IMAGE_INTENT_EXTRA, this.images.get(position));
            bundle.putBoolean(FROM_LIST_PAGE_INTENT_EXTRA, Boolean.TRUE);
            intent.putExtras(bundle);
            startActivity(intent);
        });

        listView.setOnItemLongClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(getString(R.string.delete_this_earth_image));
            builder.setPositiveButton(getText(R.string.OK), (dialog, which) -> {
                NasaEarthImage.delete(this.dbOpener, id);
                this.images.remove(position);
                this.adapter.notifyDataSetChanged();
                Snackbar.make(getActivity().findViewById(R.id.drawer_layout), R.string.deleted_success, Snackbar.LENGTH_SHORT).show();
            }).setNegativeButton(getText(R.string.cancel), null);
            AlertDialog dialog = builder.create();
            dialog.show();
            return true;
        });

        searchBtn = root.findViewById(R.id.search_btn);
        searchBtn.setOnClickListener(e -> {
            LinearLayout layout = new LinearLayout(getContext());
            layout.setOrientation(LinearLayout.VERTICAL);

            final EditText latitudeBox = new EditText(getContext());
            latitudeBox.setHint(getString(R.string.latitude));
            latitudeBox.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);
            layout.addView(latitudeBox); // Notice this is an add method


            final EditText longitudeBox = new EditText(getContext());
            longitudeBox.setHint(getString(R.string.longitude));
            longitudeBox.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);
            layout.addView(longitudeBox); // Another add method

            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(getString(R.string.enter_longitude_latitude));
            builder.setPositiveButton(getText(R.string.OK), (dialog, which) -> {
                new EarthImageGet(Float.valueOf(latitudeBox.getText().toString()),
                        Float.valueOf(longitudeBox.getText().toString()), getContext(), this.loadingBar, this.container, this.dbOpener).execute();
            }).setNegativeButton(getText(R.string.cancel), null);
            AlertDialog dialog = builder.create();
            dialog.setView(layout, 50, 0, 50, 0);
            dialog.show();
        });

        return root;
    }


    @Override
    public void onResume() {
        this.images = NasaEarthImage.getAll(this.dbOpener);
        this.adapter.setImages(this.images);
        this.adapter.notifyDataSetChanged();
        super.onResume();
    }
}
