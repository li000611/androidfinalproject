package com.example.finalproject.ui.BBCNewsReader;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.finalproject.R;
import com.example.finalproject.adapter.BBCNewsReader.BBCNewsAdapter;
import com.example.finalproject.async.BBCNewsReader.BBCNewsGet;
import com.example.finalproject.model.BBCNewsReader.BBCNews;
import com.example.finalproject.opener.DatabaseOpener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class BBCNewsReaderFragment extends Fragment {
    public static String BBC_NEWS_INTENT_EXTRA = "news_list";
    public static String SINGLE_BBC_NEWS_INTENT_EXTRA = "news";
    public static String ALLOW_FAVORITE_INTENT_EXTRA = "allow_favorite";

    private FloatingActionButton searchBtn;
    private View root;
    private DatabaseOpener dbOpener;
    private List<BBCNews> newsList;
    private BBCNewsAdapter adapter;
    private ListView listView;
    private ProgressBar loadingBar;
    private View container;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dbOpener = new DatabaseOpener(getContext());
        root = inflater.inflate(R.layout.list_template
                , container, false);

        loadingBar = root.findViewById(R.id.loading_bar);
        loadingBar.setVisibility(View.INVISIBLE);

        this.container = root.findViewById(R.id.list_container);
        newsList = BBCNews.getAll(dbOpener);

        adapter = new BBCNewsAdapter(getContext(), newsList);

        listView = root.findViewById(R.id.template_list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            Intent intent = new Intent(getContext(), BBCNewsReaderDetail.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable(SINGLE_BBC_NEWS_INTENT_EXTRA, this.newsList.get(position));
            bundle.putBoolean(ALLOW_FAVORITE_INTENT_EXTRA, Boolean.FALSE);
            intent.putExtras(bundle);
            startActivity(intent);
        });

        listView.setOnItemLongClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(getString(R.string.delete_this_bbc_news));
            builder.setPositiveButton(getText(R.string.OK), (dialog, which) -> {
                BBCNews.delete(this.dbOpener, id);
                this.newsList.remove(position);
                this.adapter.notifyDataSetChanged();
                Snackbar.make(getActivity().findViewById(R.id.drawer_layout), R.string.deleted_success, Snackbar.LENGTH_SHORT).show();
            }).setNegativeButton(getText(R.string.cancel), null);
            AlertDialog dialog = builder.create();
            dialog.show();
            return true;
        });

        searchBtn = root.findViewById(R.id.search_btn);
        searchBtn.setOnClickListener(e -> new BBCNewsGet(getContext(), this.loadingBar, this.container).execute());
        searchBtn.setImageDrawable(getResources().getDrawable(R.drawable.ic_assignment_black_24dp, getContext().getTheme()));
        return root;
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onResume() {
        super.onResume();
        this.newsList = BBCNews.getAll(this.dbOpener);
        this.adapter.setNewsList(this.newsList);
        this.adapter.notifyDataSetChanged();
    }
}
