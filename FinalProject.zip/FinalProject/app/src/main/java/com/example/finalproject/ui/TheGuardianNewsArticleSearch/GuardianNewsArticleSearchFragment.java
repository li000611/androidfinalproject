package com.example.finalproject.ui.TheGuardianNewsArticleSearch;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.finalproject.R;
import com.example.finalproject.adapter.TheGuardianNewsArticle.GuardianNewsAdapter;
import com.example.finalproject.async.GuardianNews.GuardianNewsGet;
import com.example.finalproject.model.TheGuardianNewsArticle.GuardianArticle;
import com.example.finalproject.opener.DatabaseOpener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class GuardianNewsArticleSearchFragment extends Fragment {
    public static String GUARDIAN_NEWS_LIST_INTENT_EXTRA = "news_list";
    public static String GUARDIAN_NEWS_INTENT_EXTRA = "news";
    public static String ALLOW_FAVORITE_INTENT_EXTRA = "allow_favorite";

    private FloatingActionButton searchBtn;
    private View root;
    private DatabaseOpener dbOpener;
    private List<GuardianArticle> articles;
    private GuardianNewsAdapter adapter;
    private ListView listView;
    private ProgressBar loadingBar;
    private View container;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dbOpener = new DatabaseOpener(getContext());
        root = inflater.inflate(R.layout.list_template
                , container, false);

        loadingBar = root.findViewById(R.id.loading_bar);
        loadingBar.setVisibility(View.INVISIBLE);

        this.container = root.findViewById(R.id.list_container);
        articles = GuardianArticle.getAll(dbOpener);

        adapter = new GuardianNewsAdapter(articles, getContext());

        listView = root.findViewById(R.id.template_list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            GuardianArticle idxArticle = articles.get(position);
            Intent intent = new Intent(getContext(), GuardianArticleDetailActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable(GUARDIAN_NEWS_INTENT_EXTRA, idxArticle);
            bundle.putBoolean(ALLOW_FAVORITE_INTENT_EXTRA, Boolean.FALSE);
            intent.putExtras(bundle);
            startActivity(intent);
        });

        listView.setOnItemLongClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(getString(R.string.delete_this_guardian_news));
            builder.setPositiveButton(getText(R.string.OK), (dialog, which) -> {
                GuardianArticle.delete(this.dbOpener, id);
                this.articles.remove(position);
                this.adapter.notifyDataSetChanged();
                Snackbar.make(getActivity().findViewById(R.id.drawer_layout), R.string.deleted_success, Snackbar.LENGTH_SHORT).show();
            }).setNegativeButton(getText(R.string.cancel), null);
            AlertDialog dialog = builder.create();
            dialog.show();
            return true;
        });

        searchBtn = root.findViewById(R.id.search_btn);
        searchBtn.setOnClickListener(e -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle(getString(R.string.guardian_news_enter_your_article_search));
            final EditText input = new EditText(getContext());
            input.setInputType(InputType.TYPE_CLASS_TEXT);

            builder.setPositiveButton(getText(R.string.OK), (dialog, which) -> {
                new GuardianNewsGet(getContext(), this.loadingBar, this.container, input.getText().toString()).execute();
            }).setNegativeButton(getText(R.string.cancel), null);
            AlertDialog dialog = builder.create();
            dialog.setView(input, 50, 0, 50, 0);
            dialog.show();
        });

        return root;
    }

    @Override
    public void onResume() {
        this.articles = GuardianArticle.getAll(this.dbOpener);
        this.adapter.setArticles(this.articles);
        this.adapter.notifyDataSetChanged();
        super.onResume();
    }
}
