package com.example.finalproject.async.NasaEarthImageryDatabase;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.example.finalproject.model.NasaEarthImage.NasaEarthImage;
import com.example.finalproject.opener.DatabaseOpener;
import com.example.finalproject.ui.NasaEarthImageryDatabase.NasaEarthImageryDatabaseFragment;
import com.example.finalproject.ui.NasaEarthImageryDatabase.NasaEarthImageryDetail;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EarthImageGet extends AsyncTask<Object, Integer, Bitmap> {
    public static final String JSON_DATE_KEY = "date";
    public static final String JSON_URL_KEY = "url";

    DatabaseOpener dbOpener;
    Context ctx;
    ProgressBar progressBar;
    View container;
    float latitude;
    float longitude;
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-dd-MM");

    Date date;
    String imgUrl;
    NasaEarthImage finalImg;

    public EarthImageGet(float latitude, float longitude, Context ctx, ProgressBar progressBar, View container, DatabaseOpener dbOpener) {
        super();
        this.ctx = ctx;
        this.progressBar = progressBar;
        this.container = container;
        this.latitude = latitude;
        this.longitude = longitude;
        this.dbOpener = dbOpener;
    }


    @Override
    protected Bitmap doInBackground(Object... objects) {
        try {
            publishProgress(50);
            URL url = new URL(String.format("https://api.nasa.gov/planetary/earth/imagery/?lon=%s&lat=%s&date=2014-02-01&api_key=DEMO_KEY", this.longitude, this.latitude));
            HttpURLConnection connection = (HttpURLConnection) url
                    .openConnection();
            connection.setConnectTimeout(15000);
            connection.setDoInput(true);
            connection.connect();
            InputStream response = connection.getInputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(response, "UTF-8"), 8);
            StringBuilder sb = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            String result = sb.toString();
            JSONObject json = new JSONObject(result);

            this.date = dateFormat.parse(json.getString(JSON_DATE_KEY));
            this.imgUrl = json.getString(JSON_URL_KEY);

            this.finalImg = new NasaEarthImage(null, longitude, latitude, date, imgUrl);
            return null;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Bitmap s) {
        Intent intent = new Intent(ctx, NasaEarthImageryDetail.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(NasaEarthImageryDatabaseFragment.IMAGE_INTENT_EXTRA, this.finalImg);
        intent.putExtras(bundle);
        ctx.startActivity(intent);

        if (progressBar != null) {
            progressBar.setVisibility(View.INVISIBLE);
        }
        if (container != null) {
            container.setAlpha(1);
            container.setClickable(Boolean.TRUE);
        }
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        if (container != null) {
            container.setAlpha(0.2f);
            container.setClickable(Boolean.FALSE);
        }
    }
}
