package com.example.finalproject.model.BBCNewsReader;

import android.content.ContentValues;
import android.database.Cursor;

import com.example.finalproject.opener.DatabaseOpener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BBCNews implements Serializable {
    private Long id;
    private String title;
    private String description;
    private Date date;
    private String url;

    public BBCNews(Long id, String title, String description, Date date, String url) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.date = date;
        this.url = url;
    }

    public BBCNews() {}

    public static List<BBCNews> getAll(DatabaseOpener dbOpener) {
        List<BBCNews> res = new ArrayList<>();

        Cursor cursor = dbOpener.getReadableDatabase().query(DatabaseOpener.BBC_NEWS_TABLES_NAME, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                Long id = cursor.getLong(cursor.getColumnIndex(DatabaseOpener.BBC_NEWS_TABLE_ID_COL));
                String title = cursor.getString(cursor.getColumnIndex(DatabaseOpener.BBC_NEWS_TABLE_TITLE_COL));
                String description = cursor.getString(cursor.getColumnIndex(DatabaseOpener.BBC_NEWS_TABLE_DESCRIPTION_COL));
                Date date = new Date((long) cursor.getInt(cursor.getColumnIndex(DatabaseOpener.BBC_NEWS_TABLE_DATE_COL)) * 1000);
                String url = cursor.getString(cursor.getColumnIndex(DatabaseOpener.BBC_NEWS_TABLE_URL_COL));
                res.add(new BBCNews(id, title, description, date, url));
                cursor.moveToNext();
            }
        }

        return res;
    }

    public static int delete(DatabaseOpener dbOpener, Long id) {
        return dbOpener.getWritableDatabase().delete(DatabaseOpener.BBC_NEWS_TABLES_NAME, String.format("%s = ?", DatabaseOpener.BBC_NEWS_TABLE_ID_COL), new String[]{Long.toString(id)});
    }

    public static Long insert(DatabaseOpener dbOpener, BBCNews news) {
        ContentValues newNews = new ContentValues();
        newNews.put(DatabaseOpener.BBC_NEWS_TABLE_TITLE_COL, news.getTitle());
        newNews.put(DatabaseOpener.BBC_NEWS_TABLE_DESCRIPTION_COL, news.getDescription());
        newNews.put(DatabaseOpener.BBC_NEWS_TABLE_DATE_COL, (int) (news.getDate().getTime() / 1000));
        newNews.put(DatabaseOpener.BBC_NEWS_TABLE_URL_COL, news.getUrl());
        return dbOpener.getWritableDatabase().insert(DatabaseOpener.BBC_NEWS_TABLES_NAME, null, newNews);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
