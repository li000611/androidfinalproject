package com.example.finalproject.model.TheGuardianNewsArticle;

import android.content.ContentValues;
import android.database.Cursor;

import com.example.finalproject.opener.DatabaseOpener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class GuardianArticle implements Serializable {
    private Long id;
    private String title;
    private String url;
    private String section;


    public GuardianArticle(Long id, String title, String url, String section) {
        this.id = id;
        this.url = url;
        this.title = title;
        this.section = section;
    }

    public static List<GuardianArticle> getAll(DatabaseOpener dbOpener) {
        List<GuardianArticle> res = new ArrayList<>();

        Cursor cursor = dbOpener.getReadableDatabase().query(DatabaseOpener.GUARDIAN_NEWS_TABLE_NAME, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                Long id = cursor.getLong(cursor.getColumnIndex(DatabaseOpener.GUARDIAN_NEWS_TABLE_ID_COL));
                String url = cursor.getString(cursor.getColumnIndex(DatabaseOpener.GUARDIAN_NEWS_TABLE_URL_COL));
                String title = cursor.getString(cursor.getColumnIndex(DatabaseOpener.GUARDIAN_NEWS_TABLE_TITLE_COL));
                String section = cursor.getString(cursor.getColumnIndex(DatabaseOpener.GUARDIAN_NEWS_TABLE_SECTION_COL));

                res.add(new GuardianArticle(id, title, url, section));

                cursor.moveToNext();
            }
        }

        return res;
    }

    public static Long insert(DatabaseOpener dbOpener, GuardianArticle article) {
        ContentValues newArticle = new ContentValues();
        newArticle.put(DatabaseOpener.GUARDIAN_NEWS_TABLE_URL_COL, article.getUrl());
        newArticle.put(DatabaseOpener.GUARDIAN_NEWS_TABLE_TITLE_COL, article.getTitle());
        newArticle.put(DatabaseOpener.GUARDIAN_NEWS_TABLE_SECTION_COL, article.getSection());
        return dbOpener.getWritableDatabase().insert(DatabaseOpener.GUARDIAN_NEWS_TABLE_NAME, null, newArticle);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public static int delete(DatabaseOpener dbOpener, Long id) {
        return dbOpener.getWritableDatabase().delete(DatabaseOpener.GUARDIAN_NEWS_TABLE_NAME, String.format("%s = ?", DatabaseOpener.GUARDIAN_NEWS_TABLE_ID_COL), new String[]{Long.toString(id)});
    }
}
