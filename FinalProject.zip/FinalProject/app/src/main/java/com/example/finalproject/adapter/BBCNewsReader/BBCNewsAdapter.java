package com.example.finalproject.adapter.BBCNewsReader;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.finalproject.R;
import com.example.finalproject.model.BBCNewsReader.BBCNews;

import java.text.SimpleDateFormat;
import java.util.List;

public class BBCNewsAdapter extends BaseAdapter {
    private List<BBCNews> newsList;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    private Context ctx;

    public BBCNewsAdapter(Context ctx, List<BBCNews> list) {
        setNewsList(list);
        this.ctx = ctx;
    }


    public void setNewsList(List<BBCNews> newsList) {
        this.newsList = newsList;
    }

    @Override
    public int getCount() {
        return newsList.size();
    }

    @Override
    public BBCNews getItem(int position) {
        return newsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        Long res = newsList.get(position).getId();
        return res == null ? 0 : res;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(this.ctx);
            convertView = inflater.inflate(R.layout.bbc_news_list_item, parent, false);
        }

        TextView titleView = convertView.findViewById(R.id.bbc_news_list_item_title);
        TextView descView = convertView.findViewById(R.id.bbc_list_item_description);
        TextView dateView = convertView.findViewById(R.id.bbc_list_item_date);

        BBCNews news = newsList.get(position);
        titleView.setText(news.getTitle());
        descView.setText(news.getDescription());
        dateView.setText(dateFormat.format(news.getDate()));

        return convertView;
    }
}
